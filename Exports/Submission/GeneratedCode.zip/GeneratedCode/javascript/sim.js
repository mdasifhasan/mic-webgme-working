var gameEngine = new GameEngine("GameEngine");
var canvas = new Canvas("Canvas");
var testGame = new TestGame("TestGame");
var errorHandler = new ErrorHandler("ErrorHandler");
var debugTest = new Debug("Debug");
