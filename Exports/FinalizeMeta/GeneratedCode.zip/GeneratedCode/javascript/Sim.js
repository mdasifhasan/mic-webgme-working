var DataTypes = function () {
};


DataTypes.DictionarySample = function(){
    
    this.0 = function(){
    
    this.value = undefined;
    };
    
    this.1 = function(){
    
    this.value = undefined;
    };
    
    this.2 = function(){
    
    this.value = undefined;
    };
    
    this.3 = function(){
    
    this.value = undefined;
    };
    
};

DataTypes.DataSprite = function(){
    
    this.image name = function(){
    
    this.value = undefined;
    };
    
    this.y = function(){
    
    this.value = undefined;
    };
    
    this.Physics = function(){
    
    this.value = undefined;
    };
    
    this.SpriteObject = function(){
    
    this.value = undefined;
    };
    
    this.Group = function(){
    
    this.value = undefined;
    };
    
    this.x = function(){
    
    this.value = undefined;
    };
    
};

DataTypes.Primitives = function(){
    
    this.Text = function(){
    
    this.value = undefined;
    };
    
    this.ReferData = function(){
    
    this.value = undefined;
    };
    
    this.Object = function(){
    
    this.value = undefined;
    };
    
    this.Boolean = function(){
    
    this.value = undefined;
    };
    
    this.Dictionary = function(){
    
    this.value = undefined;
    };
    
    this.Number = function(){
    
    this.value = undefined;
    };
    
};

DataTypes.DataText = function(){
    
    this.Y = function(){
    
    this.value = undefined;
    };
    
    this.Text = function(){
    
    this.value = undefined;
    };
    
    this.TextObject = function(){
    
    this.value = undefined;
    };
    
    this.X = function(){
    
    this.value = undefined;
    };
    
};

