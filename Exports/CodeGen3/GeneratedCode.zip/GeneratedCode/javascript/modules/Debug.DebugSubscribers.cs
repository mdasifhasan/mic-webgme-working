
Debug.DebugSubscribers = function(){
};

Debug.DebugSubscribers.prototype.init(){
    
};


Debug.DebugSubscribers.prototype.CountDataSubscribers-refer = function(OutTotalCount, fd_IFieldData){

    console.log("Component CountDataSubscribers-refer not implemented in Module: Debug.DebugSubscribers");

};







