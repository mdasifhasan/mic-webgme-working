
ModGameEngine = function(){
};

ModGameEngine.prototype.init = function(signal_SignalUpdate, signal_SignalCreate){
    
        this.implementation = new ModuleGameEngine();
        this.implementation.init(signal_SignalUpdate, signal_SignalCreate);
    
};








