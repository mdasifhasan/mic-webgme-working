
Debug.DebugSubscribers = function(){
};

Debug.DebugSubscribers.prototype.init = function(){
    
};


Debug.DebugSubscribers.prototype.CountDataSubscribers_refer = function(OutTotalCount, fd_IFieldData){

    console.log("Component CountDataSubscribers_refer not implemented in Module: Debug.DebugSubscribers");
    return true;

};







