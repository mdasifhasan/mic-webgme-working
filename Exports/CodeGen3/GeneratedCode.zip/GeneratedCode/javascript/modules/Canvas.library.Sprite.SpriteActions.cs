
Canvas.library.Sprite.SpriteActions = function(){
};

Canvas.library.Sprite.SpriteActions.prototype.init(){
    
        this.implementation = new ModuleSpriteActions();
        this.implementation.init();
    
};


Canvas.library.Sprite.SpriteActions.prototype.CreateSprite-refer = function(DataSprite, DataSprite2, signal_Error){

        this.implementation.CreateSprite-refer(DataSprite, DataSprite2, signal_Error);

};

Canvas.library.Sprite.SpriteActions.prototype.CreateGroup-refer = function(Group-type, signal_Error){

        this.implementation.CreateGroup-refer(Group-type, signal_Error);

};







